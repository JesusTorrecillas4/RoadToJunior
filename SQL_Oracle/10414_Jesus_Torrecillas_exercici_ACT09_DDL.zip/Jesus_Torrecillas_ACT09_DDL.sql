--Ejercicio ACT 09 DDL

-- 2. CREAR TABLAS CORREGIDAS
CREATE TABLE suite(
    id_suite NUMBER,
    codi VARCHAR2(10),          
    localitzacio VARCHAR2(20),  
    tipus VARCHAR2(10),
    estat VARCHAR2(10),
    CONSTRAINT pk_suite PRIMARY KEY (id_suite)
);

CREATE TABLE tractament(
    id_tractament NUMBER,
    codi VARCHAR2(10),          
    nom VARCHAR2(50),
    durada VARCHAR2(5),
    CONSTRAINT pk_tractament PRIMARY KEY (id_tractament)
);

CREATE TABLE pollastre(
    id_pollastre NUMBER,
    codi_xip VARCHAR2(7),
    nom VARCHAR2(10),
    data_naixement DATE,
    sexe VARCHAR2(1),
    raça VARCHAR2(50),
    color VARCHAR2(15),
    id_suite NUMBER,
    CONSTRAINT pk_pollastre PRIMARY KEY (id_pollastre),
    CONSTRAINT fk_pollastre_suite FOREIGN KEY (id_suite) REFERENCES suite(id_suite)
);

CREATE TABLE reserva(
    id_reserva NUMBER,
    fecha_reserva DATE,
    id_pollastre NUMBER,
    id_tractament NUMBER,
    CONSTRAINT pk_reserva PRIMARY KEY (id_reserva),
    CONSTRAINT fk_reserva_pollastre FOREIGN KEY(id_pollastre) REFERENCES pollastre(id_pollastre),
    CONSTRAINT fk_reserva_tractament FOREIGN KEY(id_tractament) REFERENCES tractament(id_tractament)
);

-- 3. INSERTAR DATOS 

-- SUITES primero
INSERT INTO suite VALUES (1,'S413','Planta 4 Porta 13','Luxe','Lliure');
INSERT INTO suite VALUES (2,'S532','Planta 5 Porta 32','Gran Luxe','Ocupat');
INSERT INTO suite VALUES (3,'S112','Planta 1 Porta 12','Standar','Manteniment');

-- TRATAMIENTOS
INSERT INTO tractament VALUES (1,'T002','Massatge de xocolata','45min');
INSERT INTO tractament VALUES (2,'T003','Massatge balinès','45min');
INSERT INTO tractament VALUES (3,'T004','Massatge descontracturant','30min');

-- POLLASTRES (
INSERT INTO pollastre VALUES (1,'XC2312','Leonidas',TO_DATE('25/04/2005','DD/MM/YYYY'),'M','Combatiente Español','Blanc', 1);
INSERT INTO pollastre VALUES (2,'AB3256','Amaya',TO_DATE('12/03/2010','DD/MM/YYYY'),'F','Euskal Oiloa','Marró', 2);
INSERT INTO pollastre VALUES (3,'12BD32','Gazpacho',TO_DATE('10/10/2012','DD/MM/YYYY'),'M','Sureña','Marró', 3);
INSERT INTO pollastre VALUES (4,'SP34MN','Cristina',TO_DATE('25/12/2014','DD/MM/YYYY'),'F','Utrerana','Blau', 1);


--Exercici 4: VISUALIZACIÓ DE DADES 

SELECT * FROM pollastre;
SELECT * FROM tractament;

--Exercici 5: INSERCIÓ DE DADES (ÚS DE CLAUS FORANES) 



INSERT INTO tractament VALUES (4, 'T005', 'Neteja de plomes amb banys de sal', '60min');

INSERT INTO reserva VALUES (1, TO_DATE('29/11/2017', 'DD/MM/YYYY'), 1, 4);  
INSERT INTO reserva VALUES (2, TO_DATE('30/11/2017', 'DD/MM/YYYY'), 4, 1);  
INSERT INTO reserva VALUES (3, TO_DATE('30/11/2017', 'DD/MM/YYYY'), 2, 2);  
INSERT INTO reserva VALUES (4, TO_DATE('02/12/2017', 'DD/MM/YYYY'), 1, 3); 

--Exercici 6: MODIFICACIÓ DE DADES (Opcional) 

UPDATE pollastre SET codi_xip = 'ZP4512' WHERE nom = 'Amaya';
UPDATE tractament SET durada = '50min' WHERE nom = 'Massatge balinès';
UPDATE reserva SET fecha_reserva = TO_DATE('01/12/2017', 'DD/MM/YYYY') WHERE id_reserva = 4;