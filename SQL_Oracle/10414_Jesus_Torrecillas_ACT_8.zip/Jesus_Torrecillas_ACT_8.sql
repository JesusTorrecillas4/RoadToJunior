--Ejercicio  ACT 08




--Exercici 1: CREACIÓ de les taules
CREATE TABLE camionero(

    id_camionero NUMBER,
    dni VARCHAR2(10),
    telefon NUMBER,
    salari NUMBER,
    nom VARCHAR2(10),
    cognom VARCHAR2(15),
    poblacio VARCHAR2(25),
    CONSTRAINT fk_camionero PRIMARY KEY (id_camionero),
    CONSTRAINT uk_dni UNIQUE (dni),
    CONSTRAINT ck_camionero_salari CHECK (salari >= 0)
);

CREATE TABLE camion(

    id_camion NUMBER,
    matricula VARCHAR2(7),
    model VARCHAR2(50),
    tipus VARCHAR2(50),
    potencia VARCHAR2(50),
    CONSTRAINT pk_camion PRIMARY KEY (id_camion),
    CONSTRAINT uk_matricula UNIQUE(matricula)
);

CREATE TABLE conduce(

    id_conduce NUMBER,
    data_inici DATE,
    data_fin DATE,
    id_camionero NUMBER,
    id_camion NUMBER,
    CONSTRAINT fk_conduce PRIMARY KEY (id_conduce),
    CONSTRAINT fk_conduce_camionero FOREIGN KEY (id_camionero) REFERENCES camionero(id_camionero),
    CONSTRAINT fk_conduce_camion FOREIGN KEY (id_camion) REFERENCES camion(id_camion)


);


CREATE TABLE provincia(

    id_provincia NUMBER,
    codi NUMBER,
    nom VARCHAR2(50),
    CONSTRAINT pk_provincia PRIMARY KEY (id_provincia)
);

CREATE TABLE paquet(

    id_paquet NUMBER,
    codi NUMBER,
    descripcio VARCHAR2(50),
    carrer VARCHAR2(50),
    destinatari VARCHAR2(50),
    id_camionero NUMBER,
    id_provincia NUMBER,
    CONSTRAINT pk_paquet PRIMARY KEY(id_paquet),
    CONSTRAINT ch_paquet_codi CHECK (codi IS NOT NULL),
    CONSTRAINT pk_paquet_camionero FOREIGN KEY (id_camionero) REFERENCES camionero(id_camionero),
    CONSTRAINT pk_paquet_provincia FOREIGN KEY (id_provincia) REFERENCES provincia(id_provincia)
);

--Exercici 2: INSERCIÓ de dades

INSERT INTO camionero VALUES(1,'5431414T',767859483,2.300,'Manolo','Perez','Sabadell');
INSERT INTO camionero VALUES(2,'6353242G',752246664,2.800,'Raul','Gomez','Terrassa');
INSERT INTO camionero VALUES(3,'7445635U',764324452,2.050,'Alex','Rodriguez','Manresa');
INSERT INTO camionero VALUES(4,'3524524R',626721541,3.200,'Monica','Salazar','Sabadell');

INSERT INTO camion VALUES(1,'4521UFT','BMW','Tractora','325 CV');
INSERT INTO camion VALUES(2,'5222JHA','Citroen','Americano','385 CV');
INSERT INTO camion VALUES(3,'6323OPA','Mercedes','Tractora','295 CV');

INSERT INTO conduce VALUES(1,'10/09/2022','30/09/2022',1,1);
INSERT INTO conduce VALUES(2,'14/05/2019','03/06/2019',2,2);
INSERT INTO conduce VALUES(3,'26/08/2018','09/09/2018',3,3);

INSERT INTO provincia VALUES(1,922,'Terrassa');
INSERT INTO provincia VALUES(2,817,'Sabadell');

INSERT INTO paquet VALUES(1,463,'Mueble','Ponts','Juan',1,1);
INSERT INTO paquet VALUES(2,131,'Electrodomestico','Madrid','Marta',2,2);

--Exercici 3: MODIFICACIÓ de taules 

 ALTER TABLE camionero ADD data_naixement DATE;
 
--Exercici 4: MODIFICACIÓ de registres 

UPDATE camionero SET data_naixement = '10/03/1989' WHERE id_camionero = 1;
UPDATE camionero SET data_naixement = '24/09/2000' WHERE id_camionero = 2;
UPDATE camionero SET data_naixement = '30/01/1964' WHERE id_camionero = 3;
UPDATE camionero SET data_naixement = '15/03/1989' WHERE id_camionero = 4;

--Exercici 5: MODIFICACIÓ de registres


UPDATE paquet SET id_provincia = 1 WHERE id_paquet = 2;

--Exercici 6

DELETE FROM camionero WHERE id_camionero = 4;

--Exercici 7 


DROP TABLE camion CASCADE CONSTRAINTS PURGE;
DROP TABLE camionero CASCADE CONSTRAINTS PURGE;
DROP TABLE conduce CASCADE CONSTRAINTS PURGE;
DROP TABLE paquet CASCADE CONSTRAINTS PURGE;
DROP TABLE provincia CASCADE CONSTRAINTS PURGE;

COMMIT;